return {
    "saghen/blink.cmp",
    dependencies = { "rafamadriz/friendly-snippets" },
    version = "1.*",
    opts = {
        keymap = {
            preset = "super-tab",
            ["<C-u>"] = { "scroll_signature_up", "fallback" },
            ["<C-d>"] = { "scroll_signature_down", "fallback" },
        },
        appearance = { nerd_font_variant = "mono" },
        completion = {
            documentation = { auto_show = false },
        },
        sources = {
            default = { "lsp", "path", "snippets", "buffer" },
        },
        fuzzy = { implementation = "prefer_rust_with_warning" },
        signature = { enabled = true },
    },
    opts_extend = { "sources.default" },
}
