return {
    "nvim-neo-tree/neo-tree.nvim",
    branch = "v3.x",
    dependencies = {
        "nvim-lua/plenary.nvim",
        "MunifTanjim/nui.nvim",
        "nvim-tree/nvim-web-devicons",
    },
    lazy = false,
    config = function()
        vim.keymap.set("n", "<leader>e", "<Cmd>Neotree<CR>", { desc = "Open Neo-tree" })

        require("neo-tree").setup({
            popup_border_style = "",
            window = { position = "float" },
            filesystem = {
                follow_current_file = {
                    enabled = true,
                    leave_dirs_open = true,
                },
            },
            buffers = {
                follow_current_file = {
                    enabled = true,
                    leave_dirs_open = true,
                },
            },
        })
    end,
}
