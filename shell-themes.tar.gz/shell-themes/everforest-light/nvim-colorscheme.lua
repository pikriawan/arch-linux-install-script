return {
    "sainnhe/everforest",
    lazy = false,
    priority = 1000,
    config = function()
        vim.opt.background = "light"
        vim.cmd.colorscheme("everforest")
    end,
}
