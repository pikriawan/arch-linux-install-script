const fs = require("node:fs");
const path = require("node:path");

function fillMissingStateEntry(stateObject) {
    const defaultState = {
        "font.mono": "JetBrains Mono",
        "font.mono_nerd": "JetBrainsMono Nerd Font",
        "font.sans": "Ubuntu",
        "font.sans_nerd": "NotoSans Nerd Font",
        "theme.path": path.resolve(__dirname, "themes/gruvbox-dark"),
        "theme.color.foreground": "ebdbb2",
        "theme.color.background": "282828",
        "theme.color.outline": "3e3e3e",
        "theme.color.outline_variant": "535353",
        "theme.color.success": "98971a",
        "theme.color.warning": "d79921",
        "theme.color.danger": "cc241d",
        "theme.value.gtk_color_scheme": "prefer-dark",
        "theme.value.gtk_icon_theme": "Yaru-yellow-dark",
        "wallpaper.path": path.resolve(__dirname, "themes/gruvbox-dark/wallpapers/pexels-kim-jinhong-866465-7745268.jpg")
    };

    const result = stateObject;

    for (const [key, value] of Object.entries(defaultState)) {
        if (result[key] === undefined) {
            result[key] = value;
        }
    }

    return result;
}

function ensureStateFileExists() {
    const stateDir = path.resolve(process.env.HOME, ".local/state/theme-manager");

    if (!fs.existsSync(stateDir)) {
        fs.mkdirSync(stateDir, { recursive: true });
    } else if (!fs.lstatSync(stateDir).isDirectory()) {
        fs.rmSync(stateDir);
        fs.mkdirSync(stateDir);
    }

    const stateFile = path.resolve(stateDir, "state.json");

    if (!fs.existsSync(stateFile)) {
        fs.writeFileSync(stateFile, "{}");
    }
}

function ensureStateFileValid() {
    ensureStateFileExists();

    const stateFile = path.resolve(process.env.HOME, ".local/state/theme-manager/state.json");

    let stateObject = {};

    try {
        stateObject = JSON.parse(fs.readFileSync(stateFile, "utf8"));

        if (typeof stateObject !== "object" || stateObject === null || Array.isArray(stateObject)) {
            stateObject = {};
        }
    } catch (error) {
        console.log(error);
    }

    fs.writeFileSync(stateFile, JSON.stringify(fillMissingStateEntry(stateObject)));
}

function list() {
    ensureStateFileValid();

    const stateFile = path.resolve(process.env.HOME, ".local/state/theme-manager/state.json");
    return JSON.parse(fs.readFileSync(stateFile, "utf8"));
}

function get(key) {
    if (typeof key !== "string") {
        throw new Error("key must be a string");
    }

    ensureStateFileValid();

    const stateFile = path.resolve(process.env.HOME, ".local/state/theme-manager/state.json");
    const state = JSON.parse(fs.readFileSync(stateFile, "utf8"));
    return state[key];
}

function set(key, value) {
    if (typeof key !== "string") {
        throw new Error("key must be a string");
    }

    if (typeof value !== "string") {
        throw new Error("value must be a string");
    }

    ensureStateFileValid();

    const stateFile = path.resolve(process.env.HOME, ".local/state/theme-manager/state.json");
    const stateObject = JSON.parse(fs.readFileSync(stateFile, "utf8"));
    stateObject[key] = value;
    fs.writeFileSync(stateFile, JSON.stringify(stateObject));
}

function del(key) {
    if (typeof key !== "string") {
        throw new Error("key must be a string");
    }

    ensureStateFileValid();

    const stateFile = path.resolve(process.env.HOME, ".local/state/theme-manager/state.json");
    const stateObject = JSON.parse(fs.readFileSync(stateFile, "utf8"));
    stateObject[key] = undefined;
    fs.writeFileSync(stateFile, JSON.stringify(stateObject));
}

module.exports = { list, get, set, del };
