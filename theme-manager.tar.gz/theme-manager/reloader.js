const fs = require("node:fs");

function render(template, stateObject) {
    let result = template;

    for (const [key, value] of Object.entries(stateObject)) {
        result = result.replaceAll(`{${key}}`, value);
    }

    return result;
}

function reload(targets, state) {
    for (const target of targets) {
        const srcFile = typeof target.src === "function" ? target.src(state) : target.src;
        const src = fs.readFileSync(srcFile, "utf8");
        const rendered = render(src, state.list());
        fs.writeFileSync(target.dest, rendered);

        if (typeof target.reload === "function") {
            target.reload(state);
        }
    }
}

module.exports = { reload };
