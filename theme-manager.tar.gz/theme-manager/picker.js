const child_process = require("node:child_process");

function pick(prompt, placeholder, choices) {
    try {
        return child_process.execSync(
            `echo -e "${choices.join("\n")}" | rofi -dmenu -i -p ${prompt} -theme-str 'entry { placeholder: "${placeholder}"; }'`,
            { encoding: "utf8" }
        ).trim();
    } catch {
        return null;
    }
}

module.exports = { pick };
