const child_process = require("node:child_process");

function reload(proc) {
    const pid = child_process.execSync(`pidof ${proc} || true`, { encoding: "utf8" }).trim();

    if (pid) {
        child_process.execSync(`kill ${pid}`);
    }

    const child = child_process.spawn(proc, {
        detached: true,
        stdio: "ignore"
    });

    child.unref();
}

module.exports = { reload };
