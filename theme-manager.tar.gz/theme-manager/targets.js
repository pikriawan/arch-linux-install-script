const child_process = require("node:child_process");
const path = require("node:path");
const proc = require("./proc");

const targets = [
    {
        src(state) {
            return path.resolve(state.get("theme.path"), "alacritty");
        },
        dest: path.resolve(process.env.HOME, ".config/alacritty/theme.toml")
    },
    {
        src(state) {
            return path.resolve(state.get("theme.path"), "btop");
        },
        dest: path.resolve(process.env.HOME, ".config/btop/themes/system.theme")
    },
    {
        src(state) {
            return path.resolve(state.get("theme.path"), "neovim");
        },
        dest: path.resolve(process.env.HOME, ".config/nvim/lua/plugins/colorscheme.lua")
    },
    {
        src: path.resolve(__dirname, "templates/fontconfig"),
        dest: path.resolve(process.env.HOME, ".config/fontconfig/fonts.conf"),
        reload() {
            child_process.execSync("fc-cache");
        }
    },
    {
        src: path.resolve(__dirname, "templates/hyprland"),
        dest: path.resolve(process.env.HOME, ".config/hypr/hyprland.lua"),
        reload(state) {
            child_process.execSync(`gsettings set org.gnome.desktop.interface color-scheme ${state.get("theme.value.gtk_color_scheme")}`);
            child_process.execSync(`gsettings set org.gnome.desktop.interface document-font-name '${state.get("font.sans")} 12'`);
            child_process.execSync(`gsettings set org.gnome.desktop.interface font-name '${state.get("font.sans")} 11'`);
            child_process.execSync(`gsettings set org.gnome.desktop.interface icon-theme ${state.get("theme.value.gtk_icon_theme")}`);
            child_process.execSync(`gsettings set org.gnome.desktop.interface monospace-font-name '${state.get("font.mono")} 11'`);
        }
    },
    {
        src: path.resolve(__dirname, "templates/hyprlock"),
        dest: path.resolve(process.env.HOME, ".config/hypr/hyprlock.conf")
    },
    {
        src: path.resolve(__dirname, "templates/hyprpaper"),
        dest: path.resolve(process.env.HOME, ".config/hypr/hyprpaper.conf"),
        reload() {
            proc.reload("hyprpaper");
        }
    },
    {
        src: path.resolve(__dirname, "templates/mako"),
        dest: path.resolve(process.env.HOME, ".config/mako/config"),
        reload() {
            child_process.execSync("makoctl reload");
        }
    },
    {
        src: path.resolve(__dirname, "templates/rofi"),
        dest: path.resolve(process.env.HOME, ".config/rofi/config.rasi")
    },
    {
        src: path.resolve(__dirname, "templates/waybar"),
        dest: path.resolve(process.env.HOME, ".config/waybar/style.css"),
        reload() {
            proc.reload("waybar");
        }
    },
];

module.exports = targets;
